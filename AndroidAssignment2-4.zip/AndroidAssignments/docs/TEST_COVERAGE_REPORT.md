# Test Coverage Report — AndroidAssignments CP470 Assignment 2

## JaCoCo Configuration

JaCoCo is configured in `app/build.gradle.kts` using **offline instrumentation** so that
Robolectric's sandbox classloader picks up the coverage probes:

```kotlin
jacoco {
    toolVersion = "0.8.14"
}
```

The `instrumentClassesForJacoco` Gradle task pre-instruments the compiled app classes with
JaCoCo probes before each unit test run. The `jacocoUnitTestReport` task then reads the
resulting exec file and generates the HTML/XML coverage report.

## Running Coverage

**Unit test coverage (offline instrumentation — works with Robolectric):**
```
./gradlew coverageReport
```
*(Do not run `jacocoUnitTestReport` directly — it requires the `-Pjacoco.coverage=true` flag
which `coverageReport` sets automatically. Running tests from Android Studio IDE is unaffected.)*
Report: `app/build/reports/coverage/test/debug/index.html`

**Instrumented test coverage (on-device):**
```
./gradlew createDebugAndroidTestCoverageReport
```

---

## Unit Test Results

| Test Class | Tests | Passed | Failed |
|---|---|---|---|
| `ChatWindowActivityUnitTest` | 9 | 9 | 0 |
| `MainActivityUnitTest` | 7 | 7 | 0 |
| `LoginActivityUnitTest` | 8 | 8 | 0 |
| `ListItemsActivityUnitTest` | 10 | 10 | 0 |
| `LocalizationUnitTest` | 2 | 2 | 0 |
| `ManifestUnitTest` | 3 | 3 | 0 |
| `ChatMessageListUnitTest` | 6 | 6 | 0 |
| `TestToolbarActivityUnitTest` | 16 | 16 | 0 |
| `ExampleUnitTest` | 1 | 1 | 0 |
| **Total** | **62** | **62** | **0** |

---

## Test Classes and What They Verify

| Test Class | Type | What It Verifies |
|---|---|---|
| `ChatWindowActivityUnitTest` | Unit (Robolectric) | Views found; adapter starts empty; send adds message; input cleared; order preserved; empty send blocked; incoming/outgoing row layouts differ; navigateUp; lifecycle |
| `MainActivityUnitTest` | Unit (Robolectric) | Start Chat button text; Start Chat launches ChatWindowActivity; button launches ListItemsActivity with requestCode 10; onActivityResult shows Toast; navigateUp; lifecycle |
| `LoginActivityUnitTest` | Unit (Robolectric) | Default email pre-filled; invalid email shows toast; empty email/password shows toast; valid login starts MainActivity; email saved to SharedPreferences; email restored on relaunch; lifecycle |
| `ListItemsActivityUnitTest` | Unit (Robolectric) | All widgets exist; radio toggles on/off; switch toast on/off; checkbox shows dialog; imageButton clickable; print() shows toast; goHome() starts MainActivity; navigateUp; lifecycle + saveInstanceState |
| `LocalizationUnitTest` | Unit (Robolectric) | English strings correct; French strings correct (start_chat, send, chat_hint, login_button, hello_message) |
| `ManifestUnitTest` | Unit (Robolectric) | ChatWindow parent is MainActivity; Main parent is LoginActivity; ListItems parent is MainActivity; android.support.PARENT_ACTIVITY meta-data present for all |
| `ChatMessageListUnitTest` | Unit (plain JUnit) | Empty list count; add increments count; get returns correct item; even=incoming, odd=outgoing; IndexOutOfBoundsException past end |
| `TestToolbarActivityUnitTest` | Unit (Robolectric) | Activity launches; FAB exists; default/updated snackbar message; menu inflates; About toast contains version and name; MainActivity has Test Toolbar button; button launches TestToolbarActivity; Go Back dialog title, negative stays, positive finishes; custom dialog has EditText, positive updates message, negative/blank leaves unchanged |
| `ExampleUnitTest` | Unit (plain JUnit) | 2+2=4 |
| `LoginActivityInstrumentedTest` | Instrumented (Espresso) | Email/password/loginButton displayed; invalid email stays on login; valid credentials finish activity |
| `ChatWindowInstrumentedTest` | Instrumented (Espresso) | Views displayed; Send button text; message visible in list; EditText cleared; 3 messages in adapter; empty message rejected; both row layouts render |
| `NavigationInstrumentedTest` | Instrumented (Espresso) | Back from ChatWindow finishes it; Up arrow from ChatWindow finishes it; Back from ListItems finishes it; startChat button does not crash |
| `ListItemsInstrumentedTest` | Instrumented (Espresso) | All Part 1 widgets displayed; radio check/uncheck; switch toggle |
| `MainActivityInstrumentedTest` | Instrumented (Espresso) | MainActivity launches; Start Chat button is visible; Start Chat button click does not crash |
| `TestToolbarInstrumentedTest` | Instrumented (Espresso) | TestToolbarActivity launches; FAB is visible; FAB click does not crash; default snackbar message correct; setSnackbarMessage updates correctly |
| `ExampleInstrumentedTest` | Instrumented | Package name correct |

---

## Coverage Results

Coverage measured with JaCoCo 0.8.14 offline instrumentation, unit tests run on JDK 21 via
Gradle toolchain, Android SDK 37 via Robolectric 4.14.1.

### Overall

| Metric | Coverage |
|---|---|
| **Line** | **85%** (263 / 309 lines) |
| **Branch** | **55%** (30 / 54 branches) |
| **Method** | **86%** (74 / 86 methods) |
| **Class** | **100%** (22 / 22 classes reached) |

### Per Activity Class

| Class | Line Coverage | Branch Coverage |
|---|---|---|
| `ChatWindowActivity` | **100%** (33 / 33) | **50%** (1 / 2) |
| `LoginActivity` | **83%** (29 / 35) | n/a |
| `MainActivity` | **87%** (39 / 45) | **62%** (5 / 8) |
| `ListItemsActivity` | **73%** (45 / 62) | **6%** (1 / 16) |
| `TestToolbarActivity` | **91%** (41 / 45) | **75%** (6 / 8) |

### Notes on Uncovered Code

- **`ListItemsActivity` branch coverage (6%)**: The activity has many listener lambdas and
  dialog-action branches (AlertDialog positive/negative/neutral buttons) that are not easily
  triggered through the Robolectric `ShadowDialog` API without Espresso. The dialog callbacks
  are covered by the instrumented tests.
- **`MainActivity` branch coverage (62%)**: The `onActivityResult` happy path is covered;
  a few minor null-check branches on the received `Intent` are not exercised.
- **`ChatWindowActivity` branch (50%, 1 of 2 missed)**: The single uncovered branch is the
  null-check guard on the adapter when `onDestroy` fires before `setContentView` completes —
  an unreachable path in normal usage.
- **`TestToolbarActivity` branch coverage (75%, 2 of 8 missed)**: The FAB `onClick` body is
  not asserted in unit tests (Snackbar is a UI side-effect not easily verified via Robolectric),
  and the blank-input guard in `showCustomMessageDialog` has one untaken branch when input is
  non-blank (covered indirectly by the positive-text test).

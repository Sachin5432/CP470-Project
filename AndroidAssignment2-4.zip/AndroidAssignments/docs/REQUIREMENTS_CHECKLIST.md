# Requirements Checklist — CP470 Assignment 2 Part 3

| Mark | Requirement | File / Method |
|---|---|---|
| +1 | MainActivity has a button to launch a chat window | `activity_main.xml` → `R.id.startChatButton`; `MainActivity.java` onClick starts `ChatWindowActivity` |
| +2 | Typing chat messages populates the chat window (send/receive) | `ChatWindowActivity.java` → `sendButton.onClickListener` adds to `messages`; `ChatAdapter.getView()` inflates `chat_row_incoming` (even) / `chat_row_outgoing` (odd) |
| +1 | EditText window gets cleared after submitting a message | `ChatWindowActivity.java` → `textInput.setText("")` after `notifyDataSetChanged()` |
| +1 | User can exit the chat back to the Start Activity | `ChatWindowActivity.java` → `onSupportNavigateUp()`; `AndroidManifest.xml` `android:parentActivityName=".MainActivity"`; covered by `NavigationInstrumentedTest` |
| +1 | Part 1 and 2 functionality still works | `ListItemsActivity.java`, `LoginActivity.java` unchanged; covered by `ListItemsInstrumentedTest`, `LoginActivityInstrumentedTest`, `ListItemsActivityUnitTest` |
| +1 | Send and Start Chat buttons translated into 2nd language | `res/values/strings.xml` → `start_chat`, `send`; `res/values-fr/strings.xml` → `Démarrer le chat`, `Envoyer`; covered by `LocalizationUnitTest` |
| +2 | Parent/child relationship declared in manifest | `AndroidManifest.xml` — `parentActivityName` + `android.support.PARENT_ACTIVITY` meta-data on MainActivity, ListItemsActivity, ChatWindowActivity; covered by `ManifestUnitTest` |
| +3 | Thorough app testing | 7 Robolectric unit test classes + 4 Espresso instrumented test classes covering all activities, navigation, localisation, adapter logic, and manifest |
| +2 | Test coverage report with high percentage | JaCoCo configured in `app/build.gradle.kts`; run `./gradlew jacocoUnitTestReport`; report at `app/build/reports/coverage/test/debug/index.html`; see `docs/TEST_COVERAGE_REPORT.md` |
| +4 | Class diagram | `docs/class_diagram.mmd` — render to PNG with `mmdc -i docs/class_diagram.mmd -o docs/class_diagram.png` (requires Node + `@mermaid-js/mermaid-cli`) |

---

# Requirements Checklist — CP470 Assignment 2 Part 4

| Mark | Requirement | File / Method |
|---|---|---|
| +1 | Launch the application and navigate to the TestToolbar. Show that your Toolbar appears with 3 icons, and a fourth About item in the settings menu. | `res/menu/toolbar_menu.xml` — 3 items with `app:showAsAction="always"` (`@drawable/ic_star`, `@drawable/ic_home`, `@drawable/ic_message`) + `action_about` with `app:showAsAction="never"`; `TestToolbarActivity.java` → `onCreateOptionsMenu()` inflates `R.menu.toolbar_menu`; activity uses `Theme.AndroidAssignments.WithActionBar` in `AndroidManifest.xml` |
| +1 | Select Item 1 in the toolbar, and show that it makes a Snackbar notification appear at the bottom of the screen. | `TestToolbarActivity.java` → `onOptionsItemSelected()` case `R.id.action_one`: `Snackbar.make(rootView, snackbarMessage, LENGTH_LONG).show()` |
| +1 | Select Item 2 in the toolbar, and select the negative button "No", or "cancel". This should not end the current activity and navigate back to the StartActivity. | `TestToolbarActivity.java` → `showGoBackDialog()` → `builder.setNegativeButton(R.string.no, ...)` does nothing; covered by `TestToolbarActivityUnitTest.goBackDialog_negativeButton_doesNotFinishActivity` |
| +1 | Select Item 3 in the toolbar, and set a new message for the Snackbar notification. | `TestToolbarActivity.java` → `showCustomMessageDialog()` → `builder.setView(R.layout.dialog_custom)` with `R.id.editTextNewMessage`; positive button updates `snackbarMessage`; covered by `TestToolbarActivityUnitTest.customDialog_positiveWithText_updatesSnackbarMessage` |
| +1 | Select Item 1 in the toolbar and show the Snackbar has a new notification message. | `TestToolbarActivity.java` → `snackbarMessage` field updated by dialog; next `action_one` click shows the new value via `Snackbar.make(rootView, snackbarMessage, ...)` |
| +1 | Select Item 2 in the toolbar, but now select the positive button so that it ends the current activity. | `TestToolbarActivity.java` → `showGoBackDialog()` → `builder.setPositiveButton(R.string.yes, ...)` calls `finish()`; covered by `TestToolbarActivityUnitTest.goBackDialog_positiveButton_finishesActivity` |
| +3 | Define a style that includes the height, padding, margins, font size, and font colours that can be applied to all buttons. Commit your work with Git, using the commit message "Finished assignment2Part4", and push the code to the repository. | `res/values/themes.xml` → `Widget.AndroidAssignments.Button` (minHeight, padding, margins, textSize, colorOnPrimary textColor); applied globally via `materialButtonStyle` in `Base.Theme.AndroidAssignments` (day) and `res/values-night/themes.xml` (night); Git commit "Finished assignment2Part4" on branch `Assignment2Part4` |
| Bonus | Unit testing and instrumental testing | `TestToolbarActivityUnitTest.java` (16 Robolectric tests covering launch, FAB, snackbar state, menu inflation, About toast, navigation, and both dialogs); `TestToolbarInstrumentedTest.java` (5 Espresso tests covering launch, FAB visibility, FAB click, snackbar message state) |

package com.example.androidassignments;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ManifestUnitTest {

    private Context context;
    private PackageManager pm;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
        pm = context.getPackageManager();
    }

    @SuppressWarnings("deprecation")
    private ActivityInfo getInfo(Class<?> activityClass)
            throws PackageManager.NameNotFoundException {
        return pm.getActivityInfo(
                new ComponentName(context, activityClass),
                PackageManager.GET_META_DATA
        );
    }

    @Test
    public void chatWindowActivity_parentIsMainActivity()
            throws PackageManager.NameNotFoundException {
        ActivityInfo info = getInfo(ChatWindowActivity.class);
        assertNotNull(info.parentActivityName);
        assertTrue(info.parentActivityName.contains("MainActivity"));
        assertNotNull(info.metaData);
        assertNotNull(info.metaData.getString("android.support.PARENT_ACTIVITY"));
    }

    @Test
    public void mainActivity_parentIsLoginActivity()
            throws PackageManager.NameNotFoundException {
        ActivityInfo info = getInfo(MainActivity.class);
        assertNotNull(info.parentActivityName);
        assertTrue(info.parentActivityName.contains("LoginActivity"));
        assertNotNull(info.metaData);
        assertNotNull(info.metaData.getString("android.support.PARENT_ACTIVITY"));
    }

    @Test
    public void listItemsActivity_parentIsMainActivity()
            throws PackageManager.NameNotFoundException {
        ActivityInfo info = getInfo(ListItemsActivity.class);
        assertNotNull(info.parentActivityName);
        assertTrue(info.parentActivityName.contains("MainActivity"));
        assertNotNull(info.metaData);
        assertNotNull(info.metaData.getString("android.support.PARENT_ACTIVITY"));
    }
}

package com.example.androidassignments;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.view.View;
import android.view.ViewGroup;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.android.controller.ActivityController;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ChatWindowActivityUnitTest {

    private ActivityController<ChatWindowActivity> controller;
    private ChatWindowActivity activity;
    private ListView listView;
    private EditText textInput;
    private Button sendButton;

    @Before
    public void setUp() {
        controller = Robolectric.buildActivity(ChatWindowActivity.class).setup();
        activity = controller.get();
        listView = activity.findViewById(R.id.listView);
        textInput = activity.findViewById(R.id.textInput);
        sendButton = activity.findViewById(R.id.sendButton);
    }

    @After
    public void tearDown() {
        if (!activity.isDestroyed()) {
            controller.destroy();
        }
    }

    @Test
    public void views_areFound() {
        assertNotNull(listView);
        assertNotNull(textInput);
        assertNotNull(sendButton);
    }

    @Test
    public void adapter_isNonNullAndEmptyAfterCreate() {
        assertNotNull(listView.getAdapter());
        assertEquals(0, listView.getAdapter().getCount());
    }

    @Test
    public void sendMessage_addsToAdapter() {
        textInput.setText("Hello");
        sendButton.performClick();
        assertEquals(1, listView.getAdapter().getCount());
        assertEquals("Hello", listView.getAdapter().getItem(0));
    }

    @Test
    public void sendMessage_clearsEditText() {
        textInput.setText("Hello");
        sendButton.performClick();
        assertEquals("", textInput.getText().toString());
    }

    @Test
    public void multipleMessages_stayInOrder() {
        textInput.setText("First");
        sendButton.performClick();
        textInput.setText("Second");
        sendButton.performClick();
        textInput.setText("Third");
        sendButton.performClick();

        ListAdapter adapter = listView.getAdapter();
        assertEquals(3, adapter.getCount());
        assertEquals("First", adapter.getItem(0));
        assertEquals("Second", adapter.getItem(1));
        assertEquals("Third", adapter.getItem(2));
    }

    @Test
    public void emptyMessage_doesNotAddRow() {
        textInput.setText("");
        sendButton.performClick();
        assertEquals(0, listView.getAdapter().getCount());
    }

    @Test
    public void incomingRow_hasTextViewFirst() {
        textInput.setText("Msg0");
        sendButton.performClick();
        textInput.setText("Msg1");
        sendButton.performClick();

        ListAdapter adapter = listView.getAdapter();

        View incomingView = adapter.getView(0, null, listView);
        ViewGroup incomingLayout = (ViewGroup) incomingView;
        assertEquals(R.id.messageText, incomingLayout.getChildAt(0).getId());
        assertTrue(incomingLayout.getChildAt(1) instanceof ImageView);

        View outgoingView = adapter.getView(1, null, listView);
        ViewGroup outgoingLayout = (ViewGroup) outgoingView;
        assertTrue(outgoingLayout.getChildAt(0) instanceof ImageView);
        assertEquals(R.id.messageText, outgoingLayout.getChildAt(1).getId());
    }

    @Test
    public void navigateUp_returnsTrueAndFinishes() {
        assertTrue(activity.onSupportNavigateUp());
        assertTrue(activity.isFinishing());
    }

    @Test
    public void lifecycle_runsWithoutCrash() {
        controller.pause().stop().start().resume().pause().stop().destroy();
    }
}

package com.example.androidassignments;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class LocalizationUnitTest {

    @Test
    public void defaultLocale_hasEnglishStrings() {
        Context ctx = ApplicationProvider.getApplicationContext();
        assertEquals("Start Chat", ctx.getString(R.string.start_chat));
        assertEquals("Send", ctx.getString(R.string.send));
        assertEquals("Type a message...", ctx.getString(R.string.chat_hint));
        assertEquals("Login", ctx.getString(R.string.login_button));
        assertEquals("Hello World!", ctx.getString(R.string.hello_message));
    }

    @Config(qualifiers = "fr")
    @Test
    public void frenchLocale_hasTranslatedStrings() {
        Context ctx = ApplicationProvider.getApplicationContext();
        assertEquals("Démarrer le chat", ctx.getString(R.string.start_chat));
        assertEquals("Envoyer", ctx.getString(R.string.send));
        assertEquals("Tapez un message...", ctx.getString(R.string.chat_hint));
        assertEquals("Connexion", ctx.getString(R.string.login_button));
        assertEquals("Bonjour!", ctx.getString(R.string.hello_message));
    }
}

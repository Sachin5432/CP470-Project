package com.example.androidassignments;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.shadow.api.Shadow;
import org.robolectric.shadows.ShadowActivity;
import org.robolectric.shadows.ShadowToast;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class LoginActivityUnitTest {

    private ActivityController<LoginActivity> controller;
    private LoginActivity activity;

    @Before
    public void setUp() {
        ApplicationProvider.getApplicationContext()
                .getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
                .edit().clear().commit();
        controller = Robolectric.buildActivity(LoginActivity.class).setup();
        activity = controller.get();
    }

    @After
    public void tearDown() {
        if (!activity.isDestroyed()) {
            controller.destroy();
        }
    }

    @Test
    public void emailField_hasDefaultText() {
        EditText emailField = activity.findViewById(R.id.loginEmail);
        assertEquals("email@domain.com", emailField.getText().toString());
    }

    @Test
    public void invalidEmail_showsToastAndStays() {
        EditText emailField = activity.findViewById(R.id.loginEmail);
        EditText passwordField = activity.findViewById(R.id.loginPassword);
        Button loginButton = activity.findViewById(R.id.loginButton);

        emailField.setText("bad-email");
        passwordField.setText("password");
        loginButton.performClick();

        assertEquals(activity.getString(R.string.invalid_email),
                ShadowToast.getTextOfLatestToast());
        ShadowActivity shadow = Shadow.extract(activity);
        assertNull(shadow.getNextStartedActivity());
    }

    @Test
    public void emptyEmail_showsToast() {
        EditText emailField = activity.findViewById(R.id.loginEmail);
        EditText passwordField = activity.findViewById(R.id.loginPassword);

        emailField.setText("");
        passwordField.setText("password");
        activity.findViewById(R.id.loginButton).performClick();

        assertEquals(activity.getString(R.string.invalid_email),
                ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void emptyPassword_showsToast() {
        EditText emailField = activity.findViewById(R.id.loginEmail);
        EditText passwordField = activity.findViewById(R.id.loginPassword);

        emailField.setText("valid@example.com");
        passwordField.setText("");
        activity.findViewById(R.id.loginButton).performClick();

        assertEquals(activity.getString(R.string.empty_password),
                ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void validCredentials_startMainActivity() {
        EditText emailField = activity.findViewById(R.id.loginEmail);
        EditText passwordField = activity.findViewById(R.id.loginPassword);

        emailField.setText("valid@example.com");
        passwordField.setText("password123");
        activity.findViewById(R.id.loginButton).performClick();

        android.content.Intent started = ((ShadowActivity) Shadow.extract(activity)).getNextStartedActivity();
        assertNotNull(started);
        assertEquals(MainActivity.class.getName(),
                started.getComponent().getClassName());
    }

    @Test
    public void validLogin_savesEmailToPrefs() {
        EditText emailField = activity.findViewById(R.id.loginEmail);
        EditText passwordField = activity.findViewById(R.id.loginPassword);

        emailField.setText("saved@example.com");
        passwordField.setText("password123");
        activity.findViewById(R.id.loginButton).performClick();

        SharedPreferences prefs = activity.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        assertEquals("saved@example.com", prefs.getString("savedEmail", ""));
    }

    @Test
    public void savedEmail_restoredOnNextLaunch() {
        activity.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
                .edit().putString("savedEmail", "restored@example.com").commit();

        ActivityController<LoginActivity> newController =
                Robolectric.buildActivity(LoginActivity.class).setup();
        LoginActivity newActivity = newController.get();

        EditText emailField = newActivity.findViewById(R.id.loginEmail);
        assertEquals("restored@example.com", emailField.getText().toString());
        newController.destroy();
    }

    @Test
    public void lifecycle_runsWithoutCrash() {
        controller.pause().stop().start().resume().pause().stop().destroy();
    }
}

package com.example.androidassignments;

import android.app.Dialog;
import android.content.Intent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.RadioButton;

import androidx.appcompat.widget.SwitchCompat;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.shadow.api.Shadow;
import org.robolectric.shadows.ShadowActivity;
import org.robolectric.shadows.ShadowDialog;
import org.robolectric.shadows.ShadowToast;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ListItemsActivityUnitTest {

    private ActivityController<ListItemsActivity> controller;
    private ListItemsActivity activity;

    @Before
    public void setUp() {
        controller = Robolectric.buildActivity(ListItemsActivity.class).setup();
        activity = controller.get();
    }

    @After
    public void tearDown() {
        if (!activity.isDestroyed()) {
            controller.destroy();
        }
    }

    @Test
    public void allWidgets_exist() {
        assertNotNull(activity.findViewById(R.id.radioButton));
        assertNotNull(activity.findViewById(R.id.checkBox));
        assertNotNull(activity.findViewById(R.id.switch1));
        assertNotNull(activity.findViewById(R.id.imageButton));
        assertNotNull(activity.findViewById(R.id.homeButton));
    }

    @Test
    public void radioButton_togglesOnAndOff() {
        RadioButton radio = activity.findViewById(R.id.radioButton);
        assertFalse(radio.isChecked());
        radio.performClick();
        assertTrue(radio.isChecked());
        radio.performClick();
        assertFalse(radio.isChecked());
    }

    @Test
    public void switchOn_showsSwitchOnToast() {
        SwitchCompat sw = activity.findViewById(R.id.switch1);
        sw.setChecked(true);
        assertEquals(activity.getString(R.string.switch_on),
                ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void switchOff_showsSwitchOffToast() {
        SwitchCompat sw = activity.findViewById(R.id.switch1);
        sw.setChecked(true);
        sw.setChecked(false);
        assertEquals(activity.getString(R.string.switch_off),
                ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void checkBox_showsDialog() {
        CheckBox checkBox = activity.findViewById(R.id.checkBox);
        checkBox.setChecked(true);
        Dialog dialog = ShadowDialog.getLatestDialog();
        assertNotNull(dialog);
        assertTrue(dialog.isShowing());
    }

    @Test
    public void imageButton_hasClickListener() {
        ImageButton imageButton = activity.findViewById(R.id.imageButton);
        assertNotNull(imageButton);
        imageButton.performClick();
    }

    @Test
    public void print_showsToast() {
        activity.print("TestMessage");
        assertEquals("TestMessage", ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void goHome_startsMainActivity() {
        activity.goHome(null);
        ShadowActivity shadow = Shadow.extract(activity);
        Intent intent = shadow.getNextStartedActivity();
        assertNotNull(intent);
        assertEquals(MainActivity.class.getName(),
                intent.getComponent().getClassName());
    }

    @Test
    public void navigateUp_returnsTrueAndFinishes() {
        assertTrue(activity.onSupportNavigateUp());
        assertTrue(activity.isFinishing());
    }

    @Test
    public void lifecycle_andSaveState_runWithoutCrash() {
        android.os.Bundle state = new android.os.Bundle();
        controller.saveInstanceState(state);
        controller.pause().stop().start().resume().pause().stop().destroy();
    }
}

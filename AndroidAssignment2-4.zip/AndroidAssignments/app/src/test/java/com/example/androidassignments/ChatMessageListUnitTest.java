package com.example.androidassignments;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class ChatMessageListUnitTest {

    private ArrayList<String> messages;

    @Before
    public void setUp() {
        messages = new ArrayList<String>();
    }

    private String rowLayoutFor(int position) {
        return position % 2 == 0 ? "chat_row_incoming" : "chat_row_outgoing";
    }

    @Test
    public void emptyList_hasZeroCount() {
        assertEquals(0, messages.size());
    }

    @Test
    public void addMessage_incrementsCount() {
        messages.add("Hello");
        assertEquals(1, messages.size());
    }

    @Test
    public void getItem_returnsCorrectMessage() {
        messages.add("First");
        messages.add("Second");
        assertEquals("First", messages.get(0));
        assertEquals("Second", messages.get(1));
    }

    @Test
    public void evenPositions_areIncoming() {
        assertEquals("chat_row_incoming", rowLayoutFor(0));
        assertEquals("chat_row_incoming", rowLayoutFor(2));
        assertEquals("chat_row_incoming", rowLayoutFor(4));
    }

    @Test
    public void oddPositions_areOutgoing() {
        assertEquals("chat_row_outgoing", rowLayoutFor(1));
        assertEquals("chat_row_outgoing", rowLayoutFor(3));
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void getItemPastEnd_throwsException() {
        messages.get(0);
    }
}

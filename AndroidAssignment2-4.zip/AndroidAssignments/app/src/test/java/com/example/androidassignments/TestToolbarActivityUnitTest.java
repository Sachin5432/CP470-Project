package com.example.androidassignments;

import android.content.DialogInterface;
import android.content.Intent;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.shadow.api.Shadow;
import org.robolectric.shadows.ShadowActivity;
import org.robolectric.shadows.ShadowDialog;
import org.robolectric.shadows.ShadowLooper;
import org.robolectric.shadows.ShadowToast;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class TestToolbarActivityUnitTest {

    private ActivityController<TestToolbarActivity> controller;
    private TestToolbarActivity activity;

    @Before
    public void setUp() {
        controller = Robolectric.buildActivity(TestToolbarActivity.class).setup();
        activity = controller.get();
    }

    @After
    public void tearDown() {
        if (!activity.isDestroyed()) {
            controller.destroy();
        }
    }

    @Test
    public void activity_launchesWithoutCrash() {
        assertNotNull(activity);
    }

    @Test
    public void fabButton_exists() {
        assertNotNull(activity.findViewById(R.id.fab));
    }

    @Test
    public void defaultSnackbarMessage_isItemOneMessage() {
        assertEquals("You selected item 1", activity.getSnackbarMessage());
    }

    @Test
    public void setSnackbarMessage_updatesMessage() {
        activity.setSnackbarMessage("New test message");
        assertEquals("New test message", activity.getSnackbarMessage());
    }

    @Test
    public void onCreateOptionsMenu_inflatesMenu() {
        android.view.Menu menu = new org.robolectric.fakes.RoboMenu();
        boolean result = activity.onCreateOptionsMenu(menu);
        assertTrue(result);
        assertTrue(menu.size() > 0);
    }

    @Test
    public void aboutMenuItem_showsToastWithVersionInfo() {
        MenuItem mi = new org.robolectric.fakes.RoboMenuItem(R.id.action_about);
        activity.onOptionsItemSelected(mi);
        String toastText = ShadowToast.getTextOfLatestToast();
        assertNotNull(toastText);
        assertTrue(toastText.contains("Version 1.0"));
        assertTrue(toastText.contains("John Uribe"));
    }

    @Test
    public void lifecycle_runsWithoutCrash() {
        controller.pause().stop().start().resume().pause().stop().destroy();
    }

    @Test
    public void mainActivity_hasTestToolbarButton() {
        ActivityController<MainActivity> mainController =
                Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity mainActivity = mainController.get();
        Button btn = mainActivity.findViewById(R.id.testToolbarButton);
        assertNotNull(btn);
        mainController.destroy();
    }

    @Test
    public void testToolbarButton_launchesTestToolbarActivity() {
        ActivityController<MainActivity> mainController =
                Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity mainActivity = mainController.get();
        mainActivity.findViewById(R.id.testToolbarButton).performClick();
        ShadowActivity shadowMain = Shadow.extract(mainActivity);
        Intent started = shadowMain.getNextStartedActivity();
        assertNotNull(started);
        assertEquals(TestToolbarActivity.class.getName(),
                started.getComponent().getClassName());
        mainController.destroy();
    }

    // --- Dialog tests: action_two (Go Back) ---

    @Test
    public void selectActionTwo_showsGoBackDialogWithCorrectTitle() {
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_two));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        assertNotNull(dialog);
        assertTrue(dialog.isShowing());
        TextView title = dialog.findViewById(androidx.appcompat.R.id.alertTitle);
        assertNotNull(title);
        assertEquals(activity.getString(R.string.dialog_go_back_title),
                title.getText().toString());
    }

    @Test
    public void goBackDialog_negativeButton_doesNotFinishActivity() {
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_two));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        dialog.getButton(DialogInterface.BUTTON_NEGATIVE).performClick();
        assertFalse(activity.isFinishing());
    }

    @Test
    public void goBackDialog_positiveButton_finishesActivity() {
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_two));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).performClick();
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks();
        assertTrue(activity.isFinishing());
    }

    // --- Dialog tests: action_three (Custom Message) ---

    @Test
    public void selectActionThree_showsDialogWithMessageEditText() {
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_three));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        assertNotNull(dialog);
        assertTrue(dialog.isShowing());
        assertNotNull(dialog.findViewById(R.id.editTextNewMessage));
    }

    @Test
    public void customDialog_positiveWithText_updatesSnackbarMessage() {
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_three));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        EditText editText = dialog.findViewById(R.id.editTextNewMessage);
        editText.setText("Custom message");
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).performClick();
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks();
        assertEquals("Custom message", activity.getSnackbarMessage());
    }

    @Test
    public void customDialog_negativeButton_doesNotChangeMessage() {
        String original = activity.getSnackbarMessage();
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_three));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        EditText editText = dialog.findViewById(R.id.editTextNewMessage);
        editText.setText("Should not apply");
        dialog.getButton(DialogInterface.BUTTON_NEGATIVE).performClick();
        assertEquals(original, activity.getSnackbarMessage());
    }

    @Test
    public void customDialog_positiveWithBlankInput_doesNotChangeMessage() {
        String original = activity.getSnackbarMessage();
        activity.onOptionsItemSelected(new org.robolectric.fakes.RoboMenuItem(R.id.action_three));
        androidx.appcompat.app.AlertDialog dialog =
                (androidx.appcompat.app.AlertDialog) ShadowDialog.getLatestDialog();
        EditText editText = dialog.findViewById(R.id.editTextNewMessage);
        editText.setText("   ");
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).performClick();
        assertEquals(original, activity.getSnackbarMessage());
    }
}

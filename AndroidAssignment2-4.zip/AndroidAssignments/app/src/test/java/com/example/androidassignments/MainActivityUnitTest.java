package com.example.androidassignments;

import android.app.Activity;
import android.content.Intent;
import android.widget.Button;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.shadow.api.Shadow;
import org.robolectric.shadows.ShadowActivity;
import org.robolectric.shadows.ShadowToast;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class MainActivityUnitTest {

    private ActivityController<MainActivity> controller;
    private MainActivity activity;

    @Before
    public void setUp() {
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        activity = controller.get();
    }

    @After
    public void tearDown() {
        if (!activity.isDestroyed()) {
            controller.destroy();
        }
    }

    @Test
    public void startChatButton_existsWithCorrectText() {
        Button btn = activity.findViewById(R.id.startChatButton);
        assertNotNull(btn);
        assertEquals(activity.getString(R.string.start_chat), btn.getText().toString());
    }

    @Test
    public void startChatButton_launchesChatWindowActivity() {
        activity.findViewById(R.id.startChatButton).performClick();
        ShadowActivity shadow = Shadow.extract(activity);
        Intent started = shadow.getNextStartedActivity();
        assertNotNull(started);
        assertEquals(ChatWindowActivity.class.getName(),
                started.getComponent().getClassName());
    }

    @Test
    public void listItemsButton_launchesListItemsActivityForResult() {
        activity.findViewById(R.id.button).performClick();
        ShadowActivity shadow = Shadow.extract(activity);
        ShadowActivity.IntentForResult started = shadow.getNextStartedActivityForResult();
        assertNotNull(started);
        assertEquals(ListItemsActivity.class.getName(),
                started.intent.getComponent().getClassName());
        assertEquals(10, started.requestCode);
    }

    @Test
    public void onActivityResult_withOkResult_showsToast() {
        Intent data = new Intent();
        data.putExtra("Response", "TestValue");
        activity.onActivityResult(10, Activity.RESULT_OK, data);
        assertTrue(ShadowToast.getTextOfLatestToast()
                .contains("TestValue"));
    }

    @Test
    public void onActivityResult_withCancelResult_doesNotShowToast() {
        activity.onActivityResult(10, Activity.RESULT_CANCELED, null);
        assertNull(ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void navigateUp_returnsTrueAndFinishes() {
        assertTrue(activity.onSupportNavigateUp());
        assertTrue(activity.isFinishing());
    }


    @Test
    public void lifecycle_runsWithoutCrash() {
        controller.pause().stop().start().resume().pause().stop().destroy();
    }
}

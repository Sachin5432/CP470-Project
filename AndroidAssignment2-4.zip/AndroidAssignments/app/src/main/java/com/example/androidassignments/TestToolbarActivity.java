package com.example.androidassignments;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class TestToolbarActivity extends AppCompatActivity {

    private static final String TAG = "TestToolbarActivity";
    private String snackbarMessage = "You selected item 1";
    private View rootView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_toolbar);

        rootView = findViewById(R.id.main);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Welcome to TestToolbar! Tap the icons above.", Snackbar.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu m) {
        getMenuInflater().inflate(R.menu.toolbar_menu, m);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mi) {
        int id = mi.getItemId();

        if (id == R.id.action_one) {
            Log.d(TAG, "Option 1 selected");
            Snackbar.make(rootView, snackbarMessage, Snackbar.LENGTH_LONG).show();
            return true;
        } else if (id == R.id.action_two) {
            Log.d(TAG, "Option 2 selected");
            showGoBackDialog();
            return true;
        } else if (id == R.id.action_three) {
            Log.d(TAG, "Option 3 selected");
            showCustomMessageDialog();
            return true;
        } else if (id == R.id.action_about) {
            Toast.makeText(this, "Version 1.0, by John Uribe", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(mi);
    }

    private void showGoBackDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.dialog_go_back_title);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        });
        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Do nothing — user chose to stay
            }
        });
        builder.create().show();
    }

    private void showCustomMessageDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_custom, null);
        builder.setView(dialogView);

        EditText newMessageInput = dialogView.findViewById(R.id.editTextNewMessage);

        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                String entered = newMessageInput.getText().toString().trim();
                if (!entered.isEmpty()) {
                    snackbarMessage = entered;
                }
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Do nothing
            }
        });
        builder.create().show();
    }

    String getSnackbarMessage() {
        return snackbarMessage;
    }

    void setSnackbarMessage(String msg) {
        snackbarMessage = msg;
    }
}

package com.example.androidassignments;

import android.view.View;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class MainActivityInstrumentedTest {

    @Rule
    public ActivityScenarioRule<MainActivity> activityRule =
            new ActivityScenarioRule<>(MainActivity.class);

    @Test
    public void mainActivity_launchesSuccessfully() {
        activityRule.getScenario().onActivity(activity -> assertNotNull(activity));
    }

    @Test
    public void startChatButton_isDisplayed() {
        activityRule.getScenario().onActivity(activity ->
                assertEquals(View.VISIBLE, activity.findViewById(R.id.startChatButton).getVisibility()));
    }

    @Test
    public void startChatButton_launchesChatWindow() {
        activityRule.getScenario().onActivity(activity ->
                activity.findViewById(R.id.startChatButton).performClick());
    }
}

package com.example.androidassignments;

import android.view.View;
import android.widget.RadioButton;

import androidx.appcompat.widget.SwitchCompat;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ListItemsInstrumentedTest {

    @Rule
    public ActivityScenarioRule<ListItemsActivity> activityRule =
            new ActivityScenarioRule<>(ListItemsActivity.class);

    @Test
    public void allWidgets_areDisplayed() {
        activityRule.getScenario().onActivity(activity -> {
            assertEquals(View.VISIBLE, activity.findViewById(R.id.radioButton).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.checkBox).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.switch1).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.imageButton).getVisibility());
        });
    }

    @Test
    public void radioButton_canBeCheckedAndUnchecked() {
        activityRule.getScenario().onActivity(activity -> {
            RadioButton radio = activity.findViewById(R.id.radioButton);
            assertFalse(radio.isChecked());
            radio.performClick();
            assertTrue(radio.isChecked());
            radio.performClick();
            assertFalse(radio.isChecked());
        });
    }

    @Test
    public void switch_canBeToggled() {
        activityRule.getScenario().onActivity(activity -> {
            SwitchCompat sw = activity.findViewById(R.id.switch1);
            assertFalse(sw.isChecked());
            sw.setChecked(true);
            assertTrue(sw.isChecked());
            sw.setChecked(false);
            assertFalse(sw.isChecked());
        });
    }
}

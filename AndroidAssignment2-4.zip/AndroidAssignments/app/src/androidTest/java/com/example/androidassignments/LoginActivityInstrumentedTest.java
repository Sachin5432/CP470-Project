package com.example.androidassignments;

import android.content.Context;
import android.view.View;
import android.widget.EditText;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class LoginActivityInstrumentedTest {

    @Rule
    public ActivityScenarioRule<LoginActivity> activityRule =
            new ActivityScenarioRule<>(LoginActivity.class);

    @Before
    public void clearPrefs() {
        InstrumentationRegistry.getInstrumentation().getTargetContext()
                .getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
                .edit().clear().commit();
    }

    @Test
    public void loginFields_areDisplayed() {
        activityRule.getScenario().onActivity(activity -> {
            assertEquals(View.VISIBLE, activity.findViewById(R.id.loginEmail).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.loginPassword).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.loginButton).getVisibility());
        });
    }

    @Test
    public void invalidEmail_staysOnLoginScreen() {
        activityRule.getScenario().onActivity(activity -> {
            ((EditText) activity.findViewById(R.id.loginEmail)).setText("bad-email");
            ((EditText) activity.findViewById(R.id.loginPassword)).setText("password");
            activity.findViewById(R.id.loginButton).performClick();
            assertFalse(activity.isFinishing());
        });
    }

    @Test
    public void validLogin_startsMainActivity() {
        activityRule.getScenario().onActivity(activity -> {
            ((EditText) activity.findViewById(R.id.loginEmail)).setText("test@example.com");
            ((EditText) activity.findViewById(R.id.loginPassword)).setText("password123");
            activity.findViewById(R.id.loginButton).performClick();
            assertTrue(activity.isFinishing());
        });
    }
}

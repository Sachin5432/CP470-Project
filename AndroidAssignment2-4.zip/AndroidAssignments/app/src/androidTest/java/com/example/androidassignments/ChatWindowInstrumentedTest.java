package com.example.androidassignments;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ChatWindowInstrumentedTest {

    @Rule
    public ActivityScenarioRule<ChatWindowActivity> activityRule =
            new ActivityScenarioRule<>(ChatWindowActivity.class);

    @Test
    public void views_areDisplayed() {
        activityRule.getScenario().onActivity(activity -> {
            assertEquals(View.VISIBLE, activity.findViewById(R.id.listView).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.textInput).getVisibility());
            assertEquals(View.VISIBLE, activity.findViewById(R.id.sendButton).getVisibility());
        });
    }

    @Test
    public void sendButton_hasCorrectText() {
        activityRule.getScenario().onActivity(activity -> {
            Button sendButton = activity.findViewById(R.id.sendButton);
            assertEquals(activity.getString(R.string.send), sendButton.getText().toString());
        });
    }

    @Test
    public void sendMessage_isVisibleInList() {
        activityRule.getScenario().onActivity(activity -> {
            ((EditText) activity.findViewById(R.id.textInput)).setText("HelloWorld");
            activity.findViewById(R.id.sendButton).performClick();
            ListView lv = activity.findViewById(R.id.listView);
            assertEquals(1, lv.getAdapter().getCount());
            assertEquals("HelloWorld", lv.getAdapter().getItem(0));
        });
    }

    @Test
    public void sendMessage_clearsEditText() {
        activityRule.getScenario().onActivity(activity -> {
            ((EditText) activity.findViewById(R.id.textInput)).setText("ClearMe");
            activity.findViewById(R.id.sendButton).performClick();
            assertEquals("", ((EditText) activity.findViewById(R.id.textInput)).getText().toString());
        });
    }

    @Test
    public void threeMessages_allInAdapter() {
        activityRule.getScenario().onActivity(activity -> {
            EditText input = activity.findViewById(R.id.textInput);
            String[] msgs = {"Alpha", "Beta", "Gamma"};
            for (String msg : msgs) {
                input.setText(msg);
                activity.findViewById(R.id.sendButton).performClick();
            }
            ListView lv = activity.findViewById(R.id.listView);
            assertEquals(3, lv.getAdapter().getCount());
        });
    }

    @Test
    public void emptyMessage_doesNotAddRow() {
        activityRule.getScenario().onActivity(activity -> {
            activity.findViewById(R.id.sendButton).performClick();
            ListView lv = activity.findViewById(R.id.listView);
            assertEquals(0, lv.getAdapter().getCount());
        });
    }

    @Test
    public void bothRowLayouts_renderText() {
        activityRule.getScenario().onActivity(activity -> {
            EditText input = activity.findViewById(R.id.textInput);
            input.setText("IncomingMsg");
            activity.findViewById(R.id.sendButton).performClick();
            input.setText("OutgoingMsg");
            activity.findViewById(R.id.sendButton).performClick();
            ListView lv = activity.findViewById(R.id.listView);
            assertEquals(2, lv.getAdapter().getCount());
            assertEquals("IncomingMsg", lv.getAdapter().getItem(0));
            assertEquals("OutgoingMsg", lv.getAdapter().getItem(1));
        });
    }
}

package com.example.androidassignments;

import android.view.View;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class TestToolbarInstrumentedTest {

    @Rule
    public ActivityScenarioRule<TestToolbarActivity> activityRule =
            new ActivityScenarioRule<>(TestToolbarActivity.class);

    @Test
    public void testToolbarActivity_launchesSuccessfully() {
        activityRule.getScenario().onActivity(activity -> assertNotNull(activity));
    }

    @Test
    public void fab_isDisplayed() {
        activityRule.getScenario().onActivity(activity ->
                assertEquals(View.VISIBLE,
                        activity.findViewById(R.id.fab).getVisibility()));
    }

    @Test
    public void fab_clickDoesNotCrash() {
        activityRule.getScenario().onActivity(activity ->
                activity.findViewById(R.id.fab).performClick());
    }

    @Test
    public void defaultSnackbarMessage_isCorrect() {
        activityRule.getScenario().onActivity(activity ->
                assertEquals("You selected item 1", activity.getSnackbarMessage()));
    }

    @Test
    public void setSnackbarMessage_updatesCorrectly() {
        activityRule.getScenario().onActivity(activity -> {
            activity.setSnackbarMessage("Updated message");
            assertEquals("Updated message", activity.getSnackbarMessage());
        });
    }
}

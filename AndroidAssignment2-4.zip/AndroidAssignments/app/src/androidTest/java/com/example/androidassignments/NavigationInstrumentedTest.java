package com.example.androidassignments;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class NavigationInstrumentedTest {

    @Test
    public void backFromChatWindow_finishesActivity() {
        ActivityScenario<ChatWindowActivity> scenario = ActivityScenario.launch(ChatWindowActivity.class);
        scenario.onActivity(activity -> activity.onBackPressed());
        scenario.onActivity(activity -> assertTrue(activity.isFinishing()));
        scenario.close();
    }

    @Test
    public void upArrowFromChatWindow_finishesActivity() {
        ActivityScenario<ChatWindowActivity> scenario = ActivityScenario.launch(ChatWindowActivity.class);
        scenario.onActivity(activity -> assertTrue(activity.onSupportNavigateUp()));
        scenario.onActivity(activity -> assertTrue(activity.isFinishing()));
        scenario.close();
    }

    @Test
    public void backFromListItems_finishesActivity() {
        ActivityScenario<ListItemsActivity> scenario = ActivityScenario.launch(ListItemsActivity.class);
        scenario.onActivity(activity -> activity.onBackPressed());
        scenario.onActivity(activity -> assertTrue(activity.isFinishing()));
        scenario.close();
    }

    @Test
    public void startChatButton_doesNotCrash() {
        ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class);
        scenario.onActivity(activity ->
                activity.findViewById(R.id.startChatButton).performClick());
        scenario.close();
    }
}

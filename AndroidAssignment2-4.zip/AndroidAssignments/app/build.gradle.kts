plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    id("jacoco")
}

jacoco {
    toolVersion = "0.8.14"
}

// Custom configuration to hold the JaCoCo Ant task jar for offline instrumentation
val jacocoAntRunner: Configuration by configurations.creating { isTransitive = true }

val jacocoSrcClasses = layout.buildDirectory.dir(
    "intermediates/javac/debug/compileDebugJavaWithJavac/classes")
val jacocoOfflineClasses = layout.buildDirectory.dir(
    "intermediates/jacoco_offline_instrumented/debug")
val jacocoExecFile = layout.buildDirectory.file(
    "jacoco/testDebugUnitTest.exec")

// Instrument compiled app classes offline so Robolectric's sandbox picks up the probes
val instrumentClassesForJacoco by tasks.registering {
    dependsOn("compileDebugJavaWithJavac")
    inputs.dir(jacocoSrcClasses)
    outputs.dir(jacocoOfflineClasses)
    doLast {
        jacocoOfflineClasses.get().asFile.deleteRecursively()
        ant.withGroovyBuilder {
            "taskdef"(
                "name"      to "instrument",
                "classname" to "org.jacoco.ant.InstrumentTask",
                "classpath" to jacocoAntRunner.asPath
            )
            "instrument"("destdir" to jacocoOfflineClasses.get().asFile.absolutePath) {
                "fileset"("dir" to jacocoSrcClasses.get().asFile.absolutePath) {
                    "include"("name" to "**/*.class")
                    "exclude"("name" to "**/R.class")
                    "exclude"("name" to "**/R\$*.class")
                    "exclude"("name" to "**/BuildConfig.class")
                }
            }
        }
    }
}

android {
    namespace = "com.example.androidassignments"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.androidassignments"
        minSdk = 29
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
        debug {
            enableUnitTestCoverage = false
            enableAndroidTestCoverage = true
        }
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
            isReturnDefaultValues = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
    }
}

tasks.withType<Test>().configureEach {
    javaLauncher = javaToolchains.launcherFor {
        languageVersion = JavaLanguageVersion.of(21)
    }
    // Guard: only apply offline JaCoCo instrumentation when explicitly running coverage.
    // Without this, Android Studio's built-in JaCoCo agent causes double-instrumentation:
    //   "Cannot process instrumented class — please supply original non-instrumented classes."
    // To collect coverage run: ./gradlew coverageReport
    if (project.hasProperty("jacoco.coverage")) {
        dependsOn(instrumentClassesForJacoco)
        doFirst {
            classpath = files(jacocoOfflineClasses) + classpath
        }
        systemProperty("jacoco-agent.destfile", jacocoExecFile.get().asFile.absolutePath)
        systemProperty("jacoco-agent.output", "file")
    }
}

// Convenience task: runs tests with offline instrumentation then generates the coverage report.
// Avoids passing -Pjacoco.coverage=true manually.
tasks.register<GradleBuild>("coverageReport") {
    group = "verification"
    description = "Run unit tests with JaCoCo offline instrumentation and generate coverage report"
    tasks = listOf("testDebugUnitTest", "jacocoUnitTestReport")
    startParameter.projectProperties = mapOf("jacoco.coverage" to "true")
}

// Coverage report task that reads the offline exec file
tasks.register<JacocoReport>("jacocoUnitTestReport") {
    dependsOn("testDebugUnitTest")
    group = "verification"
    description = "Generate JaCoCo coverage report for unit tests"
    reports {
        html.required = true
        xml.required = true
        html.outputLocation = layout.buildDirectory.dir("reports/coverage/test/debug")
        xml.outputLocation = layout.buildDirectory.file("reports/coverage/test/debug/report.xml")
    }
    executionData.setFrom(jacocoExecFile)
    classDirectories.setFrom(fileTree(jacocoSrcClasses) {
        exclude("**/R.class", "**/R$*.class", "**/BuildConfig.class")
    })
    sourceDirectories.setFrom(files("${projectDir}/src/main/java"))
}

dependencies {
    implementation(platform(libs.compose.bom))
    implementation(libs.activity.compose)
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.material)
    implementation(libs.material3)
    implementation(libs.ui)
    implementation(libs.ui.graphics)
    implementation(libs.ui.tooling.preview)
    testImplementation(libs.junit)
    testImplementation(libs.robolectric)
    testImplementation(libs.ext.junit)
    testImplementation(libs.androidx.test.core)
    testImplementation(libs.androidx.arch.core.testing)
    testImplementation(libs.espresso.core)
    // JaCoCo offline runtime: collects coverage data from offline-instrumented classes
    testImplementation("org.jacoco:org.jacoco.agent:0.8.14:runtime")
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.ui.test.junit4)
    androidTestImplementation(libs.androidx.test.core)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.rules)
    debugImplementation(libs.ui.test.manifest)
    debugImplementation(libs.ui.tooling)
    // JaCoCo Ant task jar for offline instrumentation
    jacocoAntRunner("org.jacoco:org.jacoco.ant:0.8.14")
}
